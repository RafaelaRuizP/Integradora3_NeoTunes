package model;

public interface Playable {
    //interface method
    public void playContent();
}
