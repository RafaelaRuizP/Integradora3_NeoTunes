package model;

public interface Buyable {
    //interface method
    public void buySong();
}
